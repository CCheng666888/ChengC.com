import { mkdir, cp, readFile, writeFile, rm } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const out = path.join(root, 'dist');
// Clean only this project's generated output so removed media cannot survive a rebuild.
if (!path.isAbsolute(out) || path.dirname(out) !== root || path.basename(out) !== 'dist') throw new Error('Invalid output directory');
await rm(out, { recursive: true, force: true });
await mkdir(out, { recursive: true });
await cp(path.join(root, 'src'), path.join(out, 'src'), { recursive: true });
await cp(path.join(root, 'public'), path.join(out, 'public'), { recursive: true });
await writeFile(path.join(out, 'index.html'), await readFile(path.join(root, 'index.html')));
console.log('Built DOG WALK → dist/ (static files, including the local video).');
