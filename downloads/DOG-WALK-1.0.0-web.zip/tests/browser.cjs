const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),{createRequire}=require('node:module');
// Browser checks use a locally installed Playwright or the desktop's bundled runtime.
const bundled='C:/Users/19152/.cache/codex-runtimes/codex-primary-runtime/dependencies/node';
if(Number(process.versions.node.split('.')[0])<20&&fs.existsSync(bundled+'/bin/node.exe')){
  require('node:child_process').execFileSync(bundled+'/bin/node.exe',[__filename],{stdio:'inherit'});process.exit(0);
}
let chromium;try{({chromium}=require('playwright'));}catch{({chromium}=createRequire(bundled+'/runner.cjs')('playwright'));}
const root=path.resolve(__dirname,'..'),output=path.basename(path.dirname(root))==='games'?path.resolve(root,'../../output/dog-walk'):path.join(root,'test-results');fs.mkdirSync(output,{recursive:true});
const KEY='dog-walk-save-v1',errors=[],consoleErrors=[],checks=[];
let browser,server,distServer;
const attach=page=>{page.on('pageerror',e=>errors.push(e.message));page.on('console',m=>{if(m.type()==='error'&&!m.text().includes('404')&&!m.text().includes('net::ERR_FAILED'))consoleErrors.push(m.text());});};
const observe=page=>page.evaluate(async()=>{window.testGame=(await import('./src/main.js')).game;});
const saved=page=>page.evaluate(key=>JSON.parse(localStorage.getItem(key)),KEY);
const click=(page,a)=>page.locator(`[data-action="${a}"]`).first().click();
const photo=(page,name)=>page.screenshot({path:path.join(output,name+'.png'),fullPage:false,animations:'disabled'});
const done=name=>{checks.push(name);console.log('PASS '+name);};
const secret=page=>page.keyboard.type('lzt',{delay:75});
const cleanUI=async page=>assert(!/lzt|彩蛋|密码|hidden mode|secret code/i.test(await page.locator('#interface').innerText()));

async function moveTo(page,target){
  for(let i=0;i<12;i++){
    const p=await page.evaluate(()=>({x:testGame.player.x,y:testGame.player.y})),dx=target.x-p.x,dy=target.y-p.y;
    if(Math.hypot(dx,dy)<30)return;
    for(const [delta,pos,neg] of [[dx,'d','a'],[dy,'s','w']]){
      if(Math.abs(delta)<10)continue;const key=delta>0?pos:neg;
      await page.keyboard.down(key);await page.waitForTimeout(Math.min(900,Math.abs(delta)/138*1000));await page.keyboard.up(key);
    }
  }
  throw Error('Could not reach the selected mound through movement');
}

(async()=>{
  const {createServer}=await import('../scripts/dev.mjs');server=createServer(root);await new Promise(r=>server.listen(0,'127.0.0.1',r));const url=`http://127.0.0.1:${server.address().port}/`;
  const edge='C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe';browser=await chromium.launch({headless:true,...(fs.existsSync(edge)?{executablePath:edge}:{})});
  const context=await browser.newContext({viewport:{width:1440,height:900}}),page=await context.newPage();attach(page);
  await page.goto(url);await observe(page);await cleanUI(page);assert.equal(await page.locator('h1').innerText().then(t=>t.replace(/\s|®/g,'')),'DOGWALK');await photo(page,'menu');
  await click(page,'settings');await page.locator('[data-setting="sound"]').uncheck();await click(page,'close');await page.reload();await observe(page);assert.equal((await saved(page)).settings.sound,false);
  await click(page,'codex');await page.locator('[data-dog="mochi"]').click();await click(page,'close');await page.reload();await observe(page);assert.equal((await saved(page)).selectedDog,'mochi');
  await click(page,'codex');await page.locator('[data-dog="milo"]').click();await click(page,'close');
  await click(page,'achievements');assert.equal(await page.locator('.achievement-entry').count(),14);assert(!(await page.locator('#dialogs').innerText()).includes("Don't Mess"));await click(page,'close');done('menu, settings, dog selection and 13 normal achievements');

  await click(page,'start');await page.keyboard.down('d');await page.waitForTimeout(1200);await page.keyboard.up('d');
  const pos=await page.evaluate(()=>({x:testGame.player.x,gap:Math.hypot(testGame.player.x-testGame.dog.x,testGame.player.y-testGame.dog.y),meters:testGame.session.distance}));assert(pos.x>850);assert(pos.meters>5);assert(pos.gap<200);await photo(page,'game');
  await page.evaluate(()=>testGame.events.timer=.1);await page.keyboard.down('w');await page.waitForTimeout(350);await page.keyboard.up('w');await page.locator('.choice-list').waitFor();
  const type=await page.evaluate(()=>testGame.events.type);const index={frisbee:1,bird:2,dog:1,food:0,bone:1}[type];await page.locator(`[data-action="event-choice"][data-index="${index}"]`).click();
  assert(await page.evaluate(()=>testGame.session.interactions>=1));await cleanUI(page);await page.evaluate(()=>testGame.events.timer=100000);done('keyboard movement, leash AI and an actual movement-triggered event');

  await click(page,'mini-frisbee');await photo(page,'frisbee');await page.evaluate(()=>{window.originalRandom=Math.random;Math.random=()=>.01;const a=testGame.mini.active,input=document.querySelector('#throw-angle');input.value=a.targetAngle;input.dispatchEvent(new Event('input',{bubbles:true}));});
  await page.waitForFunction(()=>testGame.mini.active&&Math.abs(testGame.mini.active.power-testGame.mini.active.targetPower)<4);
  await click(page,'throw');await page.waitForFunction(()=>!testGame.mini.active);assert.equal((await saved(page)).frisbeeCatches,1);assert((await saved(page)).achievements.includes('firstCatch'));await click(page,'close');done('frisbee direction, timed throw, animated catch and achievement');

  await click(page,'mini-bone');await photo(page,'bone');const target=await page.evaluate(()=>testGame.mini.active.spots[testGame.mini.active.target]);
  await moveTo(page,target);await page.waitForFunction(()=>{const a=testGame.mini.active;if(!a)return false;const p=a.spots[a.target];return Math.hypot(testGame.dog.x-p.x,testGame.dog.y-p.y)<110;},{},{timeout:8000});
  await click(page,'sniff');assert.equal((await saved(page)).bonesFound,1);await click(page,'close');done('bone search uses real player movement, dog proximity and digging');

  await click(page,'mini-commands');await photo(page,'commands');
  for(let round=0;round<4;round++){await page.waitForFunction(r=>testGame.mini.active?.round===r&&testGame.mini.active.phase==='ready',round);const wanted=await page.locator('[data-command-wanted]').innerText();await page.locator(`[data-command="${wanted}"]`).click();}
  await page.waitForFunction(()=>!testGame.mini.active);assert.equal((await saved(page)).commandsPassed,1);await click(page,'close');
  await click(page,'mini-commands');const wanted=await page.locator('[data-command-wanted]').innerText();await page.locator(`[data-command="${wanted==='坐下'?'等待':'坐下'}"]`).click();assert((await page.locator('[data-command-feedback]').innerText()).includes('不是'));await click(page,'close');done('four command rounds, success and incorrect-input handling');

  await page.evaluate(()=>testGame.events.open('food'));await page.locator('[data-index="0"]').click();assert.equal((await saved(page)).foodsAvoided,1);
  await page.evaluate(()=>{testGame.events.open('food');testGame.events.timeLeft=.02;});await page.waitForFunction(()=>!testGame.events.active);done('food decision success and timeout both return to the walk');
  await page.evaluate(()=>{Math.random=originalRandom;testGame.saveWalk();});const before=await saved(page);await page.reload();await observe(page);assert.equal((await saved(page)).currentWalk.distance,before.currentWalk.distance);await click(page,'resume');
  assert.equal(await page.evaluate(()=>testGame.dog.stats.trust),before.dogTrust);assert(await page.evaluate(()=>testGame.session.distance>5));done('refresh preserves in-progress distance, dog trust and activity counters');

  await click(page,'finish');await click(page,'finish-confirm');await page.locator('text=WALK COMPLETE').waitFor();await photo(page,'results');const completed=await saved(page);assert.equal(completed.totalWalks,1);assert(completed.totalDistance>5);assert(completed.bestScore>300);assert(completed.achievements.includes('first'));
  await click(page,'menu');await page.reload();await observe(page);assert.equal((await saved(page)).bestScore,completed.bestScore);await cleanUI(page);done('walk score, stars, achievement, menu return and persistent best score');

  await click(page,'start');await page.keyboard.type('lzz',{delay:70});assert(await page.locator('#archive').isHidden());
  const paused=await page.evaluate(()=>({time:testGame.session.elapsed,x:testGame.player.x,y:testGame.player.y}));await secret(page);await page.keyboard.type('lztlzt');await page.locator('#archive-video').waitFor({timeout:10000});
  await page.waitForFunction(()=>document.querySelector('#archive-video')?.readyState>=2);assert.equal(await page.locator('#archive-video').getAttribute('controls'),null);
  const videoInfo=await page.locator('video').evaluate(v=>({duration:v.duration,width:v.videoWidth,height:v.videoHeight}));assert(videoInfo.duration>0);assert(videoInfo.width>0);console.log('VIDEO '+JSON.stringify(videoInfo));
  const frozen=await page.evaluate(()=>({time:testGame.session.elapsed,x:testGame.player.x,y:testGame.player.y}));assert(Math.abs(frozen.time-paused.time)<.4);assert.equal(frozen.x,paused.x);await photo(page,'archive-player');
  await page.locator('.video-controls [data-archive="play"]').click();await page.waitForTimeout(120);assert(await page.locator('video').evaluate(v=>v.paused));
  await page.locator('#archive-volume').evaluate(el=>{el.value=.2;el.dispatchEvent(new Event('input',{bubbles:true}));});assert.equal(await page.locator('video').evaluate(v=>v.volume),.2);
  await page.locator('[data-archive="fullscreen"]').click();if(await page.evaluate(()=>!!document.fullscreenElement))await page.locator('[data-archive="fullscreen"]').click();
  await page.locator('#archive-seek').evaluate(el=>{el.value=Number(el.max)-.4;el.dispatchEvent(new Event('input',{bubbles:true}));});await page.locator('.video-controls [data-archive="play"]').click();
  await page.locator('.hidden-award').waitFor({timeout:15000});assert.equal((await saved(page)).unlockedHiddenAchievement,true);assert((await page.locator('#archive').innerText()).includes('Respect the dog.'));await photo(page,'archive-complete');
  await page.locator('[data-archive="back"]').click();assert(await page.locator('#archive').isHidden());await page.keyboard.down('d');await page.waitForTimeout(400);await page.keyboard.up('d');assert(await page.evaluate(()=>testGame.player.x>790));
  await secret(page);assert(await page.locator('#archive').isHidden());done('wrong code is silent; playback, seek, volume, fullscreen, actual ended event, award and original-game return');
  await page.reload();await observe(page);assert.equal((await saved(page)).unlockedHiddenAchievement,true);await click(page,'achievements');assert((await page.locator('#dialogs').innerText()).includes("Don't Mess With The Dog"));await click(page,'close');done('completed archive achievement survives refresh and appears only after unlocking');

  const missingContext=await browser.newContext({viewport:{width:1280,height:800}}),missing=await missingContext.newPage();attach(missing);await missing.route('**/public/videos/lzt.mp4',route=>route.fulfill({status:404,contentType:'text/plain',body:'not found'}));
  await missing.goto(url);await observe(missing);await secret(missing);await missing.locator('text=ARCHIVE FILE NOT FOUND').waitFor({timeout:10000});await photo(missing,'archive-missing');assert.equal((await saved(missing)).unlockedHiddenAchievement,false);await missing.locator('.archive-header [data-archive="back"]').click();await click(missing,'start');await missing.keyboard.down('d');await missing.waitForTimeout(400);await missing.keyboard.up('d');assert(await missing.evaluate(()=>testGame.player.x>800));await missingContext.close();done('missing video produces a friendly fallback and normal gameplay still works');

  const badContext=await browser.newContext(),bad=await badContext.newPage();attach(bad);await bad.route('**/public/videos/lzt.mp4',route=>route.fulfill({status:200,contentType:'video/mp4',body:'invalid video'}));await bad.goto(url);await secret(bad);await bad.locator('text=RECORDING UNAVAILABLE').waitFor({timeout:10000});await bad.locator('.archive-header [data-archive="back"]').click();assert(await bad.locator('[data-action="start"]').isVisible());await badContext.close();done('unplayable video is handled without a blank screen');

  for(const width of [390,320]){
    const mobileContext=await browser.newContext({viewport:{width,height:844},isMobile:true,hasTouch:true}),mobile=await mobileContext.newPage();attach(mobile);await mobile.goto(url);await observe(mobile);assert(await mobile.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));await photo(mobile,`menu-${width}`);await click(mobile,'start');
    const r=await mobile.locator('#joystick').boundingBox(),cdp=await mobileContext.newCDPSession(mobile);await cdp.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{x:r.x+r.width/2,y:r.y+r.height/2}]});await cdp.send('Input.dispatchTouchEvent',{type:'touchMove',touchPoints:[{x:r.x+r.width/2+33,y:r.y+r.height/2}]});await mobile.waitForTimeout(750);await cdp.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});
    assert(await mobile.evaluate(()=>testGame.player.x>850));assert.equal(await mobile.evaluate(()=>testGame.input.stick.x),0);await photo(mobile,`mobile-${width}`);
    await mobile.locator('[data-action="interact"]').tap();await mobile.locator('[data-care="pet"]').tap();assert.equal((await saved(mobile)).interactions,1);
    await click(mobile,'mini-bone');assert(await mobile.locator('#bone-banner').isVisible());assert(await mobile.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));await click(mobile,'close');
    await click(mobile,'pause');await click(mobile,'menu');await click(mobile,'settings');await click(mobile,'reset-confirm');assert.equal((await saved(mobile)).interactions,1);await click(mobile,'reset-now');assert.equal((await saved(mobile)).totalWalks,0);assert.equal((await saved(mobile)).interactions,0);assert(await mobile.locator('[data-action="start"]').isVisible());await mobileContext.close();
    done(`mobile ${width}px: real touch joystick, touch interaction, search banner and confirmed save reset`);
  }

  const quotaContext=await browser.newContext();await quotaContext.addInitScript(()=>Storage.prototype.setItem=()=>{throw new DOMException('full','QuotaExceededError');});const quota=await quotaContext.newPage();attach(quota);await quota.goto(url);await click(quota,'start');assert((await quota.locator('[data-hud="save"]').innerText()).includes('不可用'));assert((await quota.locator('#toasts').innerText()).includes('无法存档'));await quotaContext.close();done('blocked storage remains playable and shows save status');
  const autoContext=await browser.newContext(),auto=await autoContext.newPage();attach(auto);await auto.goto(url);await observe(auto);await click(auto,'start');await auto.evaluate(()=>testGame.session.elapsed=testGame.session.duration-.03);await auto.locator('text=WALK COMPLETE').waitFor();assert.equal((await saved(auto)).totalWalks,1);await autoContext.close();done('timer expiry automatically completes the walk');

  distServer=createServer(path.join(root,'dist'));await new Promise(r=>distServer.listen(0,'127.0.0.1',r));const built=await context.newPage();attach(built);await built.goto(`http://127.0.0.1:${distServer.address().port}/`);assert(await built.locator('[data-action="start"]').isVisible());await click(built,'start');assert(await built.locator('[data-hud="time"]').isVisible());await secret(built);await built.locator('#archive-video').waitFor({timeout:10000});await built.waitForFunction(()=>document.querySelector('#archive-video')?.readyState>=2);await built.close();done('built distribution starts and loads its local video');
  assert.deepEqual(errors,[]);assert.deepEqual(consoleErrors,[]);const report={date:'2026-10-07',checks,unexpectedPageErrors:errors,unexpectedConsoleErrors:consoleErrors,video:videoInfo};fs.writeFileSync(path.join(output,'test-report.json'),JSON.stringify(report,null,2));console.log('BROWSER_OK '+checks.length+' checks; no unexpected console or page errors');
})().catch(e=>{console.error(e);process.exitCode=1;}).finally(async()=>{if(browser)await browser.close();for(const s of [server,distServer])if(s){s.closeAllConnections();await new Promise(r=>s.close(r));}});
