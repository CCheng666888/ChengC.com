import test from 'node:test';
import assert from 'node:assert/strict';
import { Storage, SAVE_KEY } from '../src/game/Storage.js';
import { SecretSystem } from '../src/game/SecretSystem.js';
import { Game } from '../src/game/Game.js';
import { Dog } from '../src/game/Dog.js';
import { DOGS } from '../src/data/dogs.js';
import { AchievementSystem } from '../src/game/AchievementSystem.js';
import { createServer } from '../scripts/dev.mjs';
import { fileURLToPath } from 'node:url';

const memory = () => {const map=new Map();return {getItem:k=>map.get(k)||null,setItem:(k,v)=>map.set(k,v)};};

test('walk, cumulative data, settings and completed archive survive reload',()=>{
  const backend=memory(),s=new Storage(backend);
  Object.assign(s.data,{bestScore:810,totalWalks:3,totalDistance:1428,dogTrust:92,achievements:['first','frisbee'],unlockedHiddenAchievement:true,archiveDiscovered:true});
  s.data.settings.sound=false;
  s.data.currentWalk={player:{x:810,y:770},dog:{x:850,y:780},stats:{happiness:87,energy:80,obedience:76,curiosity:86,trust:92},elapsed:65,distance:428,duration:180,score:90,visits:['grove'],interactions:2,games:1};
  assert(s.save());const next=new Storage(backend);
  assert.equal(next.data.bestScore,810);assert.equal(next.data.totalDistance,1428);assert.equal(next.data.currentWalk.distance,428);assert.deepEqual(next.data.currentWalk.visits,['grove']);assert.equal(next.data.currentWalk.stats.trust,92);assert.equal(next.data.settings.sound,false);assert.equal(next.data.unlockedHiddenAchievement,true);
});
test('broken and unavailable storage do not crash the game; values are sanitized',()=>{
  const backend=memory();backend.setItem(SAVE_KEY,'invalid-json');const broken=new Storage(backend);assert.equal(broken.data.totalWalks,0);assert.equal(broken.available,false);
  const bad=new Storage({getItem:()=>{throw Error('blocked');},setItem:()=>{throw Error('quota');}});assert.equal(bad.save(),false);assert.equal(bad.data.dogTrust,55);
  backend.setItem(SAVE_KEY,JSON.stringify({version:1,dogTrust:200,achievements:'oops',totalWalks:-9,settings:{volume:2,duration:7}}));const clean=new Storage(backend);assert.equal(clean.data.dogTrust,100);assert.equal(clean.data.totalWalks,0);assert.deepEqual(clean.data.achievements,[]);assert.equal(clean.data.settings.volume,1);assert.equal(clean.data.settings.duration,180);
});
test('reset creates fresh records without sharing mutable defaults',()=>{
  const s=new Storage(memory());s.data.achievements.push('first');s.data.unlockedHiddenAchievement=true;s.data.totalWalks=12;assert(s.reset());const next=new Storage(s.backend);assert.equal(next.data.totalWalks,0);assert.equal(next.data.unlockedHiddenAchievement,false);assert.deepEqual(next.data.achievements,[]);
});
test('input buffer stays silent on wrong keys, ignores modifiers and locks during playback',()=>{
  const s=Object.create(SecretSystem.prototype);Object.assign(s,{buffer:'',lastInput:0,busy:false,cooldownUntil:0});let calls=0;s.trigger=()=>{calls++;s.busy=true;};
  const press=(key,more={})=>s.listen({key,target:{tagName:'BODY'},...more});
  for(const k of 'lzz')press(k);assert.equal(calls,0);press('l',{ctrlKey:true});press('z');press('t');assert.equal(calls,0);
  s.buffer='';for(const k of 'LZT')press(k);assert.equal(calls,1);for(const k of 'lztlzt')press(k);assert.equal(calls,1);
  s.busy=false;s.buffer='';s.lastInput=Date.now()-3000;press('l');press('ArrowRight');press('z');press('t');assert.equal(calls,1);
  s.buffer='';press('l');s.lastInput-=3000;press('z');press('t');assert.equal(calls,1);
  s.cooldownUntil=Date.now()+5000;for(const k of 'lzt')press(k);assert.equal(calls,1);
});
test('walk completion records score and achievements once, including finished distance',()=>{
  const g=Object.create(Game.prototype);g.storage=new Storage(memory());g.state='playing';g.suspended=false;
  g.session={distance:428,score:110,visits:new Set(['lawn','grove','garden','fountain']),interactions:5,games:1};g.dog={stats:{happiness:87,energy:82,obedience:76,curiosity:90,trust:92}};
  g.mini={cancel(){}};g.events={active:null};g.input={clear(){}};g.ui={closeModal(){},toast(){},results(r){g.result=r;}};g.audio={play(){}};g.achievements=new AchievementSystem(g);
  g.finish();assert.equal(g.storage.data.totalWalks,1);assert.equal(g.storage.data.totalDistance,428);assert(g.result.score>500);assert(g.storage.data.achievements.includes('first'));assert(g.storage.data.achievements.includes('explorer'));assert(g.storage.data.achievements.includes('patience'));
  g.finish();assert.equal(g.storage.data.totalWalks,1);assert.equal(new Storage(g.storage.backend).data.bestScore,g.result.score);
});
test('attributes are bounded and low energy makes a dog move more slowly',()=>{
  const fast=new Dog(DOGS[0],55),slow=new Dog(DOGS[0],55),world={props:[],move(a,x,y){a.x+=x;a.y+=y;}};
  slow.stats.energy=8;fast.stats.energy=100;const player={x:970,y:830,direction:1,moving:true},start=slow.x;
  fast.update(.1,player,world);slow.update(.1,player,world);assert(fast.x-start>slow.x-start);slow.change({energy:-500,happiness:900,trust:1000});assert.equal(slow.stats.energy,0);assert.equal(slow.stats.happiness,100);assert.equal(slow.stats.trust,100);
});
test('server supports video HEAD and byte ranges and handles missing files',async()=>{
  const root=fileURLToPath(new URL('../',import.meta.url)),server=createServer(root.replace(/[\\/]$/,''));await new Promise(r=>server.listen(0,'127.0.0.1',r));
  const url=`http://127.0.0.1:${server.address().port}`;
  try{const head=await fetch(url+'/public/videos/lzt.mp4',{method:'HEAD'});assert.equal(head.status,200);assert.equal(head.headers.get('content-type'),'video/mp4');assert(Number(head.headers.get('content-length'))>1000);
    const range=await fetch(url+'/public/videos/lzt.mp4',{headers:{Range:'bytes=0-31'}});assert.equal(range.status,206);assert.equal((await range.arrayBuffer()).byteLength,32);
    const missing=await fetch(url+'/public/videos/missing.mp4');assert.equal(missing.status,404);
    const invalid=await fetch(url+'/public/videos/lzt.mp4',{headers:{Range:'bytes=999999999999-'}});assert.equal(invalid.status,416);
  }finally{server.closeAllConnections();await new Promise(r=>server.close(r));}
});
