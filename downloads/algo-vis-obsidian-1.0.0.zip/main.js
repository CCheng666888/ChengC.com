/**
 * algo-vis Obsidian 插件主入口。
 * 功能：① 命令「演示选中的代码」 ② 选中代码浮出按钮 ③ 代码块 algovis 声明式演示 ④ 左侧栏可视化台图标。
 */
"use strict";
const obsidian = require("obsidian");
const AlgoEngine = require("./algo-engine");

module.exports = class AlgoVisPlugin extends obsidian.Plugin {
  async onload() {
    // ① 命令
    this.addCommand({
      id: "demo-selection",
      name: "演示选中的代码",
      editorCallback: (editor, ctx) => {
        const code = editor.getSelection();
        if (!code || !code.trim()) {
          new obsidian.Notice("算法动图：请先在编辑器中选中代码。");
          return;
        }
        this.openDemo(editor, code);
      },
    });

    // ② 选中浮出按钮（编辑器扩展）
    this.registerEditorExtension(createSelectionButtonExtension(this));

    // ③ 代码块 algovis 声明式演示
    this.registerMarkdownCodeBlockProcessor("algovis", (source, el, ctx) => {
      const parsed = parseDecl(source);
      const demoRoot = el.createDiv({ cls: "algovis-block" });
      AlgoDemo.render(demoRoot, parsed);
    });

    // ④ 左侧栏可视化台图标
    this.addRibbonIcon("bar-chart", "算法动图可视化台", () => {
      this.openVisualizer();
    });

    // 状态栏提示
    this.addStatusBarItem().setText("算法动图已启用");
  }

  openDemo(editor, code) {
    const algo = AlgoEngine.detectAlgorithm(code);
    const panel = new DemoModal(this.app, editor, code, algo);
    panel.open();
  }

  openVisualizer() {
    const view = new VisualizerModal(this.app);
    view.open();
  }
};

/* ===== 声明式代码块解析：算法 / 数组 / 目标 等 ===== */
function parseDecl(src) {
  const out = {};
  const lines = String(src).split("\n");
  lines.forEach((line) => {
    const m = line.match(/^\s*([^:：]+)\s*[:：]\s*(.+?)\s*$/);
    if (m) {
      const key = m[1].trim(), val = m[2].trim();
      if (/算法/.test(key)) out.algo = val;
      else if (/数组|array/i.test(key)) out.arr = val.split(/[,\s]+/).map(Number);
      else if (/目标|target/i.test(key)) out.target = Number(val);
      else if (/间隔|gap|k\b/i.test(key)) out.k = Number(val);
      else if (/数字|n\b/i.test(key)) out.n = Number(val);
    }
  });
  return out;
}

/* ===== 选中浮出按钮扩展 ===== */
function createSelectionButtonExtension(plugin) {
  const { EditorView, ViewPlugin, Decoration, DecorationSet, WidgetType } = obsidian;
  class ButtonWidget extends WidgetType {
    constructor(plugin, code) {
      super();
      this.plugin = plugin;
      this.code = code;
    }
    toDOM() {
      const btn = document.createElement("button");
      btn.className = "algovis-float-btn";
      btn.textContent = "演示算法";
      btn.addEventListener("click", (e) => {
        e.preventDefault();
        e.stopPropagation();
        this.plugin.openDemo(null, this.code);
      });
      return btn;
    }
  }
  const selectionPlugin = ViewPlugin.fromClass(
    class {
      constructor(view) {
        this.decorations = this.build(view);
      }
      update(update) {
        this.decorations = this.build(update.view);
      }
      build(view) {
        const ranges = [];
        view.state.selection.ranges.forEach((r) => {
          if (r.empty) return;
          const from = r.from, to = r.to;
          const text = view.state.doc.sliceString(from, to);
          if (!text || !text.trim()) return;
          const end = view.state.doc.lineAt(to).to;
          ranges.push(Decoration.widget({ widget: new ButtonWidget(this.plugin, text), side: 1 }).range(end, end));
        });
        return Decoration.set(ranges);
      }
    }
  );
  return selectionPlugin;
}

/* ===== 演示弹窗（命令/按钮复用） ===== */
class DemoModal extends obsidian.Modal {
  constructor(app, editor, code, algo) {
    super(app);
    this.code = code;
    this.algo = algo;
    this.editor = editor;
  }
  onOpen() {
    const { contentEl } = this;
    contentEl.empty();
    contentEl.addClass("algovis-modal");
    AlgoDemo.renderModal(contentEl, this.algo, this.code);
  }
  onClose() {
    const { contentEl } = this;
    contentEl.empty();
  }
}

/* ===== 可视化台弹窗 ===== */
class VisualizerModal extends obsidian.Modal {
  constructor(app) {
    super(app);
    this.titleEl.setText("算法动图 · 可视化台");
  }
  onOpen() {
    const { contentEl } = this;
    contentEl.empty();
    contentEl.addClass("algovis-modal");
    AlgoDemo.renderModal(contentEl, { zh: "冒泡排序", en: "bubble sort" }, null);
  }
  onClose() {
    const { contentEl } = this;
    contentEl.empty();
  }
}

/* ===== 演示渲染（纯 DOM，复用引擎） ===== */
const AlgoDemo = {
  render(root, parsed) {
    root.createDiv({ cls: "algovis-box", text: "算法动图 · 点击下方按钮查看演示" });
    const btn = root.createEl("button", { text: "▶ 播放演示", cls: "algovis-play-btn" });
    btn.addEventListener("click", () => {
      root.empty();
      this.renderPlayer(root, { zh: parsed.algo || "冒泡排序" }, parsed);
    });
  },
  renderModal(root, algo, code) {
    const opts = {};
    if (code) {
      const algo2 = AlgoEngine.detectAlgorithm(code);
      opts.code = code;
      opts.algo = algo2;
    } else {
      opts.algo = algo;
    }
    this.renderPlayer(root, opts.algo || algo, opts);
  },
  renderPlayer(root, algo, opts) {
    const algoId = opts.algo && opts.algo.id
      ? opts.algo.id
      : (AlgoEngine.detectAlgorithm(opts.code || algo.zh).id);
    const steps = AlgoEngine.buildSteps(algoId, {
      code: opts.code || "",
      arr: opts.arr || AlgoEngine.DEFAULT_ARR,
      target: opts.target,
      k: opts.k,
      n: opts.n,
    });
    root.empty();
    root.createEl("h3", { text: "算法动图 · " + (algo.zh || "演示"), cls: "algovis-title" });

    const box = root.createDiv({ cls: "algovis-demo" });
    const goal = box.createDiv({ cls: "algovis-goal", text: AlgoEngine.GOALS[algoId] || "" });
    const cells = box.createDiv({ cls: "algovis-cells" });
    const desc = box.createDiv({ cls: "algovis-desc", text: "" });
    const bar = box.createDiv({ cls: "algovis-bar" });
    const playBtn = bar.createEl("button", { text: "暂停" });
    const resetBtn = bar.createEl("button", { text: "重置" });
    const speedSel = bar.createEl("select", { cls: "algovis-speed" });
    ["0.5x", "1x", "2x", "4x"].forEach((v, i) => {
      const o = speedSel.createEl("option", { text: v, value: v });
      if (i === 1) o.selected = true;
    });
    const stepEl = bar.createEl("span", { cls: "algovis-step", text: "" });

    let idx = 0, timer = null;
    const speeds = { "0.5x": 2400, "1x": 1400, "2x": 700, "4x": 350 };
    let cur = 1400;

    let cellEls = [], arrLen = 0;
    function ensureCells(n) {
      if (n === arrLen) return;
      cells.empty(); cellEls = []; arrLen = n;
      for (let i = 0; i < n; i++) {
        const c = cells.createDiv({ cls: "algovis-cell" });
        c.createSpan({ text: "" });
        c.createEl("small", { text: "[" + i + "]" });
        cellEls.push(c);
      }
    }
    function flipSwap(i, j) {
      const a = cellEls[i], b = cellEls[j];
      const ra = a.getBoundingClientRect(), rb = b.getBoundingClientRect();
      const dx = rb.left - ra.left, dy = rb.top - ra.top;
      if (i < j) cells.node.insertBefore(b.node, a.node); else cells.node.insertBefore(a.node, b.node);
      const t = cellEls[i]; cellEls[i] = cellEls[j]; cellEls[j] = t;
      a.style.transition = "none"; b.style.transition = "none";
      a.style.transform = "translate(" + dx + "px," + dy + "px)";
      b.style.transform = "translate(" + (-dx) + "px," + (-dy) + "px)";
      requestAnimationFrame(() => {
        requestAnimationFrame(() => {
          a.style.transition = "transform .5s cubic-bezier(.2,.8,.25,1)";
          b.style.transition = "transform .5s cubic-bezier(.2,.8,.25,1)";
          a.style.transform = ""; b.style.transform = "";
        });
      });
    }
    function render() {
      const st = steps[idx], mk = st.marks || {};
      if (st.arr && st.arr.length) {
        ensureCells(st.arr.length);
        st.arr.forEach((v, i) => {
          const c = cellEls[i];
          c.querySelector("span").textContent = String(v);
          c.className = "algovis-cell";
          if (mk.sorted && mk.sorted.indexOf(i) >= 0) c.addClass("a-sorted");
          if (mk.cmp && mk.cmp.indexOf(i) >= 0) c.addClass("a-cmp");
          if (mk.swap && mk.swap.indexOf(i) >= 0) c.addClass("a-swap");
        });
        if (mk.swap && mk.swap.length === 2) {
          const i0 = mk.swap[0], j0 = mk.swap[1];
          if (i0 !== j0) flipSwap(i0, j0);
        }
        if (mk.cmp && mk.cmp.length === 2 && typeof st.arr[mk.cmp[0]] === "number") {
          const oldB = cells.node.querySelector(".algovis-bubble"); if (oldB) oldB.remove();
          const left = Math.min(mk.cmp[0], mk.cmp[1]), right = Math.max(mk.cmp[0], mk.cmp[1]);
          const bub = cells.createDiv({ cls: "algovis-bubble", text: st.arr[left] + " vs " + st.arr[right] });
          bub.style.left = (left * 51 + 8) + "px";
        }
      } else {
        cells.empty(); cellEls = []; arrLen = 0;
        cells.createDiv({ cls: "algovis-empty", text: st.desc });
      }
      desc.setText(st.desc);
      stepEl.setText("步骤 " + (idx + 1) + " / " + steps.length + (idx >= steps.length - 1 ? " · 已完成" : ""));
    }
    function stop() { if (timer) { clearInterval(timer); timer = null; } playBtn.setText("播放"); }
    function play() {
      stop();
      if (idx >= steps.length - 1) idx = 0;
      playBtn.setText("暂停");
      timer = window.setInterval(() => {
        if (idx >= steps.length - 1) { stop(); render(); return; }
        idx++; render();
      }, cur);
    }
    playBtn.addEventListener("click", () => { timer ? stop() : play(); });
    resetBtn.addEventListener("click", () => { stop(); idx = 0; render(); });
    speedSel.addEventListener("change", () => { cur = speeds[speedSel.value] || 1400; });
    render(); play();
  },
};
