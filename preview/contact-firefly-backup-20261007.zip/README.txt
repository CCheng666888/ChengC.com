流萤 Contact 完整备份（2026-10-07，北京时间）。
包含原始 contact.html、原始 CSS/JS、带哈希合并资源、动画视频、图像及素材来源说明。
backup-manifest.json 记录每个原文件的 SHA-256，可校验备份完整性。
查看旧界面：主站根目录 contact-firefly-backup.html（与备份前原页字节一致）。
恢复：先保留当前新版，再将压缩包中的 contact.html 放回网站根目录；如配套资源丢失，可按原目录结构恢复 CSS/JS/assets。随后运行 node preview/build-delivery.cjs，并本地验证。
未推送、未部署。